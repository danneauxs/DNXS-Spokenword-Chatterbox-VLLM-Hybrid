"""
ChatterboxTTS Progress Tracking & Performance Monitoring Module
==============================================================

OVERVIEW:
This module provides comprehensive progress tracking, performance monitoring, and logging
for ChatterboxTTS audiobook generation. It handles real-time ETA calculations, VRAM usage
monitoring, and detailed logging for debugging and optimization.

MAIN COMPONENTS:
1. LOGGING SYSTEM: File + console logging with color-coded output
2. PROGRESS TRACKING: Real-time progress display with ETA calculations  
3. PERFORMANCE MONITORING: GPU memory usage, processing times, realtime factors
4. BATCH PROGRESS: Multi-chapter audiobook progress aggregation
5. SYSTEM MONITORING: VRAM safety thresholds and memory optimization

KEY FEATURES:
- Real-time ETA updates during TTS processing
- VRAM usage monitoring with automatic cleanup
- Performance metrics (realtime factor, chunks/minute)
- Color-coded console output for different message types
- Detailed logging for troubleshooting and optimization
- Memory-safe processing with configurable thresholds

PERFORMANCE ENHANCEMENTS:
- Added producer-consumer pipeline progress tracking
- Enhanced ETA calculations for more accurate estimates
- GPU memory monitoring prevents VRAM exhaustion
- Automatic memory cleanup and garbage collection
- Processing speed metrics for performance optimization

USAGE:
Called by TTS engine during audiobook generation to provide user feedback
and monitor system resource usage for safe, efficient processing.
"""

import time
import sys
import logging
from datetime import timedelta
from config.config import *

# Temporary safety switch — disable chunk ETA/progress updates entirely to avoid
# GUI crashes triggered by the structured status wiring.
DISABLE_CHUNK_PROGRESS = False

# ============================================================================
# LOGGING SETUP
# ============================================================================


def setup_logging(log_dir):
    """Setup logging configuration"""
    log_file = log_dir / "chunk_validation.log"

    # Clear existing log
    open(log_file, "w").close()

    logging.basicConfig(
        filename=str(log_file),
        level=logging.INFO,
        format="%(asctime)s - %(levelname)s - %(message)s",
        filemode="w",  # Overwrite existing log
    )

    # Also log to console for important messages
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)
    formatter = logging.Formatter("%(levelname)s - %(message)s")
    console_handler.setFormatter(formatter)
    logging.getLogger().addHandler(console_handler)


def log_console(message, color=None):
    """Log to both console and file with optional color"""
    color_codes = {
        "RED": RED,
        "GREEN": GREEN,
        "YELLOW": YELLOW,
        "CYAN": CYAN,
        "BOLD": BOLD,
        "RESET": RESET,
    }

    prefix = color_codes.get(color, "")
    suffix = RESET if color else ""

    print(f"{prefix}{message}{suffix}")
    logging.info(message)


def log_run(message, log_path):
    """Log chunk progress with configurable options.
    Args:
    i (int): Current chunk index.
    total_chunks (int): Total number of chunks.
    start_time (float): Start time of the process.
    total_audio_duration (float, optional): Total audio duration in seconds. Defaults to 0.0.
    skip_vram (bool, keyword-only): Whether to skip VRAM usage logging. Defaults to False.
    Returns:
    None
    """
    """Log to run file"""
    with open(log_path, "a", encoding="utf-8") as logf:
        logf.write(message + "\n")


# ============================================================================
# PROGRESS TRACKING
# ============================================================================


def log_chunk_progress(i, total_chunks, start_time, total_audio_duration=0.0, *, skip_vram=False):
    """Enhanced progress logging with configurable display frequency and average it/s"""
    if DISABLE_CHUNK_PROGRESS:
        return

    from config.config import ENABLE_PROGRESS_DISPLAY, ENABLE_AVERAGE_ITS_DISPLAY

    # Skip if progress display is disabled
    if not ENABLE_PROGRESS_DISPLAY:
        return

    elapsed = time.time() - start_time
    avg_time = elapsed / (i + 1)
    eta = avg_time * total_chunks
    remaining = eta - elapsed

    def fmt(seconds):
        """Converts seconds to a human-readable timedelta string.
        Args:
        seconds (int): The number of seconds to format.
        Returns:
        str: A string representing the formatted duration.
        """
        return str(timedelta(seconds=int(seconds)))

    # Show VRAM usage in progress unless explicitly skipped
    if skip_vram:
        allocated = 0.0
    else:
        allocated, _ = monitor_vram_usage("chunk_progress")

    # Calculate ACCURATE realtime factor using actual audio duration
    if total_audio_duration > 0 and elapsed > 0:
        actual_realtime = total_audio_duration / elapsed
        realtime_str = f"{GREEN}{actual_realtime:.2f}x{RESET}"
        audio_str = f" | Audio: {GREEN}{fmt(total_audio_duration)}{RESET}"
    else:
        actual_realtime = 0.0  # Default value when calculating
        realtime_str = f"{YELLOW}Calculating...{RESET}"
        audio_str = ""

    # Average speed display
    its_str = ""
    if ENABLE_AVERAGE_ITS_DISPLAY and elapsed > 0:
        # Prefer real running average of model it/s from terminal logger
        try:
            from modules.terminal_logger import get_running_avg_its

            real_avg_its = get_running_avg_its()
        except Exception:
            real_avg_its = None

        if real_avg_its is not None:
            its_str = f" | Avg: {CYAN}{real_avg_its:.1f} it/s{RESET}"
        else:
            # Fallback to chunk throughput with correct unit label
            ch_per_sec = (i + 1) / elapsed
            its_str = f" | Avg: {CYAN}{ch_per_sec:.1f} ch/s{RESET}"

    # Force immediate output with explicit flushing
    progress_msg = (
        f"🌀 Chunk {i+1}/{total_chunks} | ⏱ Elapsed: {CYAN}{fmt(elapsed)}{RESET} | "
        f"ETA: {CYAN}{fmt(eta)}{RESET} | Remaining: {YELLOW}{fmt(remaining)}{RESET} | "
        f"Realtime: {realtime_str} | "
        f"{'VRAM: ' + GREEN + f'{allocated:.1f}GB' + RESET if not skip_vram else 'VRAM: N/A'}"
        f"{audio_str}{its_str}"
    )

    # Throttle console progress output to every 5 chunks and avoid printing
    # partial 'Calculating...' lines except for the very first chunk.
    should_throttle = ((i + 1) % 5) == 0 or (i + 1) == 1 or (i + 1) == total_chunks
    has_audio_info = total_audio_duration > 0
    if should_throttle and (has_audio_info or (i + 1) == 1):
        print(progress_msg)

    # Add smart reload rolling average information
    try:
        from modules.smart_reload_manager import get_reload_manager
        from config.config import ENABLE_SMART_RELOAD

        if ENABLE_SMART_RELOAD:
            reload_mgr = get_reload_manager()
            stats = reload_mgr.get_statistics()

            # Only show if we have meaningful data
            if stats["baseline_performance"] and stats["current_performance"]:
                baseline = stats["baseline_performance"]
                current = stats["current_performance"]
                degradation = stats["performance_degradation_pct"]
                chunks_since_reload = stats["chunks_since_reload"]

                smart_reload_msg = (
                    f"📊 Smart Reload: {current:.1f} tok/s avg, baseline: {baseline:.1f} tok/s, "
                    f"degradation: {degradation:.1f}%, chunks since reload: {chunks_since_reload}"
                )
                if ((i + 1) % 5) == 0 or (i + 1) == 1 or (i + 1) == total_chunks:
                    print(smart_reload_msg)
    except (ImportError, Exception):
        # Silently ignore if smart reload is not available or has issues
        pass

    sys.stdout.flush()  # Force immediate output

    # Create clean status message for GUI (without ANSI color codes)
    realtime_display = (
        f"{actual_realtime:.2f}x" if actual_realtime > 0 else "Calculating..."
    )
    # Clean status mirrors above logic (no ANSI codes)
    if ENABLE_AVERAGE_ITS_DISPLAY and elapsed > 0:
        try:
            from modules.terminal_logger import get_running_avg_its

            real_avg_its = get_running_avg_its()
        except Exception:
            real_avg_its = None
        if real_avg_its is not None:
            its_display = f" | Avg: {real_avg_its:.1f} it/s"
        else:
            ch_per_sec = (i + 1) / elapsed
            its_display = f" | Avg: {ch_per_sec:.1f} ch/s"
    else:
        its_display = ""
    clean_status = (
        f"Chunk: {i+1}/{total_chunks} | Elapsed: {fmt(elapsed)} | ETA: {fmt(eta)} | Remaining: {fmt(remaining)} | "
        f"Realtime: {realtime_display} | VRAM: {allocated:.1f}GB"
        + (f" | Audio: {fmt(total_audio_duration)}" if total_audio_duration > 0 else "")
        + its_display
    )

    # Emit status to GUI if callback is available
    if (
        hasattr(log_chunk_progress, "_status_callback")
        and log_chunk_progress._status_callback
    ):
        log_chunk_progress._status_callback(clean_status)

    # Also log to file for debugging
    realtime_log = f"{actual_realtime:.2f}x" if actual_realtime > 0 else "N/A"
    if ENABLE_AVERAGE_ITS_DISPLAY and elapsed > 0:
        its_log = (
            f"{real_avg_its:.1f} it/s"
            if real_avg_its is not None
            else f"{((i + 1)/elapsed):.1f} ch/s"
        )
    else:
        its_log = "N/A"
    logging.info(
        f"Progress: Chunk {i+1}/{total_chunks}, Elapsed: {fmt(elapsed)}, "
        f"ETA: {fmt(eta)}, Realtime: {realtime_log}, Avg it/s: {its_log}, "
        f"Audio Duration: {fmt(total_audio_duration)}, VRAM: {allocated:.1f}GB"
    )


# ============================================================================
# PHASE-BASED PROGRESS (pipelines 3/4: Phase 0 conditionals -> Phase 1 tokens ->
# Phase 2 decode, replacing per-chunk progress with per-phase progress)
# ============================================================================


def _relay_status(status_data: dict):
    """Send a status dict straight to the GUI callback, or print it when headless.

    Mirrors log_chunk_progress's function-attribute callback pattern so the GUI
    can receive already-structured data with no string parsing required.
    """
    if getattr(_relay_status, "_callback", None):
        _relay_status._callback(status_data)
    else:
        parts = [f"{k}={v}" for k, v in status_data.items() if v is not None]
        print("STATUS: " + " | ".join(parts))
        sys.stdout.flush()


def emit_phase_status(
    phase,
    phase_label,
    current=None,
    total=None,
    phase_start_time=None,
    total_start_time=None,
):
    """Report phase-level progress (Phase 0/1/2/finalize) to the GUI status panel.

    Only "Current Operation" carries the phase text — there is deliberately no
    second "current phase" field duplicating it. phase 1/2 each get their own
    persistent elapsed-time slot that freezes at its last value once that phase
    ends (nothing clears it later); phase 0/finalize (phase=None) have no
    dedicated elapsed slot, only contributing to total_elapsed.

    Args:
        phase: 0, 1, 2, or None for a non-numbered step (e.g. finalize).
        phase_label: Human-readable phase description.
        current: Items completed in this phase so far, if applicable.
        total: Total items in this phase, if applicable.
        phase_start_time: time.time() when this phase began, for phase-elapsed.
        total_start_time: time.time() when the whole run began, for total-elapsed.
    """
    def fmt(seconds):
        """Formats a seconds value as an H:MM:SS string."""
        return str(timedelta(seconds=int(seconds)))

    phase_elapsed = fmt(time.time() - phase_start_time) if phase_start_time else None
    total_elapsed = fmt(time.time() - total_start_time) if total_start_time else None

    if current is not None and total:
        phase_text = f"{phase_label} ({current}/{total})"
        progress = (current, total)
    else:
        phase_text = phase_label
        progress = None
    if phase is not None:
        phase_text = f"Phase {phase}: {phase_text}"

    status = {
        "operation": phase_text,
        "progress": progress,
        "total_elapsed": total_elapsed,
    }
    if phase == 1:
        status["phase1_elapsed"] = phase_elapsed
    elif phase == 2:
        status["phase2_elapsed"] = phase_elapsed

    _relay_status(status)


def emit_final_status(elapsed=None, audio=None, realtime=None, total_elapsed=None):
    """Report the final "processing complete" summary to the GUI status panel."""
    _relay_status(
        {
            "operation": "✅ Processing Complete!",
            "elapsed": elapsed,
            "audio": audio,
            "realtime": realtime,
            "remaining": "0:00:00",
            "total_elapsed": total_elapsed,
        }
    )


def display_batch_progress(batch_start, batch_end, total_chunks):
    """Display batch processing progress"""
    batch_progress = (batch_end / total_chunks) * 100
    print(
        f"\n📊 Batch Progress: {batch_start+1}-{batch_end}/{total_chunks} ({batch_progress:.1f}%)"
    )


def display_final_summary(elapsed_time, audio_duration, chunk_count, realtime_factor):
    """Display final processing summary"""
    elapsed_td = timedelta(seconds=int(elapsed_time))
    audio_td = timedelta(seconds=int(audio_duration))

    print(f"\n🎉 {GREEN}Processing Complete!{RESET}")
    print("📊 Final Statistics:")
    print(f"   ⏱️ Processing Time: {CYAN}{elapsed_td}{RESET}")
    print(f"   🎵 Audio Duration: {GREEN}{audio_td}{RESET}")
    print(f"   📦 Total Chunks: {YELLOW}{chunk_count}{RESET}")
    print(f"   🚀 Realtime Factor: {BOLD}{realtime_factor:.2f}x{RESET}")
    print(f"   💾 Memory Efficiency: {GREEN}Optimized{RESET}")


# ============================================================================
# VRAM AND PERFORMANCE MONITORING
# ============================================================================


def monitor_vram_usage(operation_name=""):
    """Real-time VRAM monitoring with threshold warnings"""
    import torch

    if not torch.cuda.is_available():
        return 0, 0

    allocated = torch.cuda.memory_allocated() / 1024**3
    reserved = torch.cuda.memory_reserved() / 1024**3

    if allocated > VRAM_SAFETY_THRESHOLD:
        logging.warning(
            f"⚠️ High VRAM usage during {operation_name}: {allocated:.1f}GB allocated, {reserved:.1f}GB reserved"
        )
        # Trigger memory optimization if available
        optimize_memory_if_needed()

    return allocated, reserved


def monitor_gpu_utilization():
    """Monitor GPU utilization if pynvml is available"""
    try:
        import pynvml

        pynvml.nvmlInit()
        handle = pynvml.nvmlDeviceGetHandleByIndex(0)
        util = pynvml.nvmlDeviceGetUtilizationRates(handle)
        temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)

        return {"gpu_util": util.gpu, "memory_util": util.memory, "temperature": temp}
    except:
        return {"gpu_util": "N/A", "memory_util": "N/A", "temperature": "N/A"}


def optimize_memory_if_needed():
    """Trigger memory optimization when thresholds are exceeded"""
    try:
        # Try to use the enhanced CUDA memory optimization if available
        from modules.tts_engine import optimize_cuda_memory_usage

        optimize_cuda_memory_usage()
    except ImportError:
        # Fallback to basic optimization
        import torch
        import gc

        torch.cuda.empty_cache()
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.ipc_collect()


def display_system_info():
    """Display system information at startup"""
    import torch

    print(f"\n🖥️ {CYAN}System Information:{RESET}")

    # CUDA info
    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
        total_vram = torch.cuda.get_device_properties(0).total_memory / 1024**3
        print(f"   GPU: {GREEN}{gpu_name}{RESET}")
        print(f"   VRAM: {GREEN}{total_vram:.1f}GB{RESET}")
        print(f"   CUDA Version: {GREEN}{torch.version.cuda}{RESET}")
    else:
        print(f"   GPU: {RED}Not Available{RESET}")

    # Memory threshold
    print(f"   VRAM Safety Threshold: {YELLOW}{VRAM_SAFETY_THRESHOLD}GB{RESET}")

    # Worker configuration
    print(f"   Max Workers: {YELLOW}{MAX_WORKERS}{RESET}")
    print(f"   Dynamic Workers: {YELLOW}{USE_DYNAMIC_WORKERS}{RESET}")


# ============================================================================
# PERFORMANCE TRACKING
# ============================================================================


class PerformanceTracker:
    """
    PERFORMANCE TRACKING CLASS - Core metrics collection and analysis
    ===============================================================

    PURPOSE:
    This class provides comprehensive performance monitoring for TTS processing,
    tracking timing, memory usage, and generating detailed performance reports
    for optimization and debugging.

    TRACKED METRICS:
    - Individual chunk processing times
    - VRAM usage per chunk (allocated vs reserved memory)
    - Batch processing times for multi-chapter books
    - Overall processing statistics and trends
    - Real-time factor calculations (audio time vs processing time)

    USAGE FLOW:
    1. Initialize at start of TTS session
    2. Log chunk completions during processing
    3. Track batch completions for multi-part books
    4. Generate final performance report

    BENEFITS:
    - Identifies processing bottlenecks
    - Monitors memory usage patterns
    - Provides user feedback on progress
    - Enables performance optimization
    - Helps debug processing issues
    """

    def __init__(self):
        """Initialize performance tracking with baseline metrics"""
        self.start_time = time.time()  # Session start timestamp
        self.chunk_times = []  # Individual chunk processing times
        self.vram_usage = []  # VRAM usage snapshots (chunk_id, allocated, reserved)
        self.batch_times = []  # Batch processing times for multi-chapter books

    def log_chunk_completion(self, chunk_index, audio_duration):
        """Log individual chunk completion"""
        current_time = time.time()
        chunk_time = current_time - (self.start_time + sum(self.chunk_times))

        self.chunk_times.append(chunk_time)

        # Track VRAM
        allocated, reserved = monitor_vram_usage()
        self.vram_usage.append((chunk_index, allocated, reserved))

    def log_batch_completion(self, batch_size):
        """Log batch completion"""
        if len(self.chunk_times) >= batch_size:
            batch_time = sum(self.chunk_times[-batch_size:])
            self.batch_times.append(batch_time)

    def get_performance_summary(self):
        """Get comprehensive performance summary"""
        total_time = time.time() - self.start_time
        avg_chunk_time = (
            sum(self.chunk_times) / len(self.chunk_times) if self.chunk_times else 0
        )

        vram_peak = (
            max([usage[1] for usage in self.vram_usage]) if self.vram_usage else 0
        )
        vram_avg = (
            sum([usage[1] for usage in self.vram_usage]) / len(self.vram_usage)
            if self.vram_usage
            else 0
        )

        return {
            "total_time": total_time,
            "avg_chunk_time": avg_chunk_time,
            "total_chunks": len(self.chunk_times),
            "vram_peak": vram_peak,
            "vram_average": vram_avg,
            "batch_count": len(self.batch_times),
        }


# ============================================================================
# ERROR AND WARNING TRACKING
# ============================================================================


def log_processing_error(chunk_id, error_message, error_type="GENERAL"):
    """Log processing errors with categorization"""
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    error_log = f"[{timestamp}] {error_type} ERROR - Chunk {chunk_id}: {error_message}"

    logging.error(error_log)
    print(f"{RED}❌ Error in chunk {chunk_id}: {error_message}{RESET}")


def log_processing_warning(chunk_id, warning_message, warning_type="GENERAL"):
    """Log processing warnings with categorization"""
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    warning_log = (
        f"[{timestamp}] {warning_type} WARNING - Chunk {chunk_id}: {warning_message}"
    )

    logging.warning(warning_log)
    print(f"{YELLOW}⚠️ Warning in chunk {chunk_id}: {warning_message}{RESET}")


# ============================================================================
# REAL-TIME STATUS DISPLAY
# ============================================================================


def create_status_line(
    current_chunk, total_chunks, elapsed_time, realtime_factor, vram_usage
):
    """Create a single-line status for real-time updates"""
    progress_percent = (current_chunk / total_chunks) * 100
    elapsed_str = str(timedelta(seconds=int(elapsed_time)))

    status = (
        f"🔄 {current_chunk}/{total_chunks} ({progress_percent:.1f}%) | "
        f"⏱️ {elapsed_str} | 🚀 {realtime_factor:.2f}x | 💾 {vram_usage:.1f}GB"
    )

    return status


def update_status_line(status_message):
    """Update status line in place"""
    print(f"\r{status_message}", end="", flush=True)


# ============================================================================
# EXPORT FUNCTIONS
# ============================================================================


def export_performance_report(output_dir, performance_data):
    """Export detailed performance report"""
    report_path = output_dir / "performance_report.txt"

    with open(report_path, "w", encoding="utf-8") as f:
        f.write("GenTTS Performance Report\n")
        f.write("=" * 50 + "\n\n")

        f.write("Processing Summary:\n")
        f.write(
            f"  Total Processing Time: {timedelta(seconds=int(performance_data['total_time']))}\n"
        )
        f.write(f"  Average Chunk Time: {performance_data['avg_chunk_time']:.2f}s\n")
        f.write(f"  Total Chunks Processed: {performance_data['total_chunks']}\n")
        f.write(f"  Peak VRAM Usage: {performance_data['vram_peak']:.2f}GB\n")
        f.write(f"  Average VRAM Usage: {performance_data['vram_average']:.2f}GB\n")
        f.write(f"  Batch Count: {performance_data['batch_count']}\n")

    return report_path
